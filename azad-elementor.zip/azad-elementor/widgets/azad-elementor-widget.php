<?php
class Azad_Elementor_Widget extends \Elementor\Widget_Base {
    //public function __construct() {}
    public function get_name() {
        return 'Azad';
    }
    public function get_title() {
        return 'Azad Menu';
    }
    public function get_icon() {
        return 'fa fa-check-circle';
    }
    public function get_categories() {
        return ['basic'];
    }
    protected function _register_controls(){
        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'url',
			[
				'label' => __( 'URL to embed', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'url',
				'placeholder' => __( 'https://your-link.com', 'plugin-name' ),
			]
		);

		$this->end_controls_section();

    }
    protected function render(){
        $settings = $this->get_settings_for_display();

		$html = wp_oembed_get( $settings['url'] );

		echo '<div class="oembed-elementor-widget">';

		echo ( $html ) ? $html : $settings['url'];

		echo 'Azadh</div>';
                if(function_exists('wp_nav_menu')){
                            $defaults = array(
                                'theme_location'  => 'azad_menu',
                                'menu'            => '',
                                'container'       => 'div',
                                'container_class' => '',
                                'container_id'    => '',
                                'menu_class'      => 'nav navbar-nav',
                                'menu_id'         => '',
                                'echo'            => true,
                                'fallback_cb'     => 'wp_page_menu',
                                'before'          => '',
                                'after'           => '',
                                'link_before'     => '',
                                'link_after'      => '',
                                'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                                'depth'           => 0,
                                'walker'          => ''
                            );
                            wp_nav_menu($defaults);
                        }elseif(has_nav_menu('sidebar_widget_one')){
                            echo "Pleas set the menu first";
                        }

    }
    protected function __content_template(){
        ?>
        <div class="" style="background:blue;">{{{settings.title}}}</div> 
        <?php
    }
    //public function __destruct(){}
}